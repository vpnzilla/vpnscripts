<div style="margin-bottom: 30px" class="tutor-mr-160">
	<h6 data-source="email-heading" class="tutor-email-heading">{email_heading}</h6>
</div>

<div class="tutor-greetings-content">
	<p class="tutor-email-greetings"><?php _e( '{user_name},', 'tutor-pro' ); ?></p>
	<div class="email-user-content" data-source="email-additional-message">{email_message}</div>
</div>
